# Quickplay Collection — standalone validation

Validation executed with Node.js syntax checking for every inline JavaScript block in every game HTML.

| Game | Inline JS blocks | External JS | Pause signal | Restart/New Game signal |
|---|---:|---:|:---:|:---:|
| `Nebula_Duel.html` | 11 | 0 | ✅ | ✅ |
| `advinhe_o_numero.html` | 2 | 0 | — | ✅ |
| `alien_threat.html` | 16 | 0 | ✅ | ✅ |
| `alien_threat_3d.html` | 12 | 0 | ✅ | ✅ |
| `atomic_raid.html` | 3 | 0 | ✅ | ✅ |
| `bow_and_arrow.html` | 5 | 0 | ✅ | ✅ |
| `brain_matrix.html` | 1 | 0 | ✅ | ✅ |
| `campo_minado.html` | 4 | 0 | ✅ | ✅ |
| `click_speed.html` | 4 | 0 | ✅ | ✅ |
| `corrida_de_cavalos.html` | 1 | 0 | — | ✅ |
| `domination_wars.html` | 1 | 0 | ✅ | ✅ |
| `dropworks.html` | 3 | 0 | ✅ | ✅ |
| `foguetinho.html` | 1 | 0 | — | — |
| `hover_heroes_25d.html` | 2 | 0 | ✅ | ✅ |
| `hover_heroes_2d.html` | 1 | 0 | ✅ | ✅ |
| `hover_heroes_3d.html` | 57 | 0 | ✅ | ✅ |
| `idle_trader.html` | 4 | 0 | ✅ | ✅ |
| `iron_delta.html` | 1 | 0 | ✅ | ✅ |
| `iron_delta_25d.html` | 1 | 0 | ✅ | ✅ |
| `jogo_da_forca.html` | 2 | 0 | ✅ | ✅ |
| `jogo_da_velha.html` | 2 | 0 | — | ✅ |
| `kombo_blocks.html` | 3 | 0 | ✅ | ✅ |
| `memory_genius.html` | 5 | 0 | ✅ | ✅ |
| `pixel_bomberman.html` | 4 | 0 | ✅ | ✅ |
| `pixel_joust.html` | 1 | 0 | ✅ | ✅ |
| `pong.html` | 2 | 0 | ✅ | ✅ |
| `psycho_worms.html` | 2 | 0 | ✅ | ✅ |
| `reef_runner.html` | 1 | 0 | — | ✅ |
| `rift_run.html` | 1 | 0 | ✅ | ✅ |
| `salve_os_gatinhos.html` | 6 | 0 | ✅ | ✅ |
| `skate_or_die.html` | 1 | 0 | ✅ | ✅ |
| `snowball_avalanche.html` | 2 | 0 | ✅ | ✅ |
| `sudoku.html` | 2 | 0 | — | — |
| `survive_ninja_mayhem.html` | 4 | 0 | ✅ | ✅ |
| `the_worm.html` | 3 | 0 | ✅ | ✅ |
| `torre_de_hanoi.html` | 2 | 0 | — | ✅ |

## Result

- Games checked: **36**
- JavaScript syntax failures: **0**
- External JavaScript dependencies: **0**
- Direct Banco do Brasil branding signals: **0**
- Remote non-JS asset warnings: **5**

## Warnings

- Nebula_Duel.html: remote non-JS assets: https://guilhermeprimata.github.io/Quickplay_Collection/index.html
- domination_wars.html: remote non-JS assets: https://guilhermeprimata.github.io/Quickplay_Collection/menu_minigames.html, https://guilhermeprimata.github.io/Quickplay_Collection/menu_minigames.html, https://guilhermeprimata.github.io/Quickplay_Collection/menu_minigames.html
- iron_delta_25d.html: remote non-JS assets: https://guilhermeprimata.github.io/Quickplay_Collection/index.html
- reef_runner.html: remote non-JS assets: https://guilhermeprimata.github.io/Quickplay_Collection/index.html
- salve_os_gatinhos.html: remote non-JS assets: https://guilhermeprimata.github.io/Quickplay_Collection/index.html
